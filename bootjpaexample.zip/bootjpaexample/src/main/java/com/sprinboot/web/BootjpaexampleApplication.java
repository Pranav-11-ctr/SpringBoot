package com.sprinboot.web;

import java.util.List;
import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import com.sprinboot.web.dao.UserRepository;
import com.sprinboot.web.entities.User;

@SpringBootApplication
public class BootjpaexampleApplication {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(BootjpaexampleApplication.class, args);
		UserRepository userRepository = context.getBean(UserRepository.class);
		
		//Save user
		
		
//		User user=new User();
//		user.setName("Pranav Kumar");
//		user.setCity("Madhubani");
//		user.setStatus("I am java Programmer");
//		
//		User user1 = userRepository.save(user);
//		System.out.println(user1);
//		
//		User user2=new User();
//		user2.setName("Prabhat Kumar");
//		user2.setCity("Madhubani");
//		user2.setStatus("I am java Programmer and web Developer");
//		
//		User user3=new User();
//		user3.setName("Murari Kumar");
//		user3.setCity("Simhatol");
//		user3.setStatus("I am java Programmer");
//		
//		List<User> list = List.of(user2,user3);
//		List<User> list2 = userRepository.saveAll(list);
//		for(User u:list2)
//		{
//			System.out.println(u);
//		}
		
		
		
		//Get User
//		List<User> list = userRepository.findAll();
//		for(User u:list)
//		{
//			System.out.println(u);
//		}
//		
//		 User user = userRepository.findById(4).get();
//		 System.out.println(user);
		 
		 //Update
//		 User user1 = userRepository.findById(3).get();
//		 user1.setName("Kishan Kumar");
//		 user1.setStatus("Web Developer");
//		 userRepository.save(user1);
//		 
//		 User user2 = userRepository.findById(2).get();
//		 user2.setName("Kamal Kumar");
//		 user2.setStatus("Web Developer");
//		 userRepository.save(user2);
		 
		
		//Delete
		
//		userRepository.deleteById(5);
//		
//		List<User> list = userRepository.findAll();
//		for(User u:list)
//		{
//			System.out.println(u);
//		}
		
		
		
		//Use of Custom method
		
		
//		 List<User> findByName = userRepository.findByName("Kishan Kumar");
//		 for(User u:findByName)
//			 System.out.println(u);
//		 
//		 System.out.println("#############");
//		 
//		 List<User> list = userRepository.findByNameAndCity("Kamal Kumar", "Madhubani");
//		 for(User u:list)
//			 System.out.println(u);
//		 
		
		 System.out.println("#############");
		List<User> list = userRepository.getAllUser();
		for(User u:list)
			System.out.println(u);
		 System.out.println("#############");
		 List<User> list2 = userRepository.getUserByName("Pranav Kumar");
		 for(User u:list2)
			 System.out.println(u);
		 
		 System.out.println("*****");
		 List<User> list3 = userRepository.getUserByName("Kamal Kumar","Madhubani");
		 for(User u:list3)
			 System.out.println(u);
		 
		 System.out.println("-----");
		 List<User> list4 = userRepository.getUsers();
		 for(User u:list4)
			 System.out.println(u);
		 
		
	}

}
